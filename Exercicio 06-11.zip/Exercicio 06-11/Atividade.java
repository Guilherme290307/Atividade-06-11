import java.util.Scanner;

public class Atividade {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int Opcao;

        do {
            System.out.println("\n=== MENU DE EXERCÍCIOS ===");
            System.out.println("1 - Exercício dos preços");
            System.out.println("2 - Exercício da matriz (RA e faltas)");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            Opcao = s.nextInt();

            switch (Opcao) {
                case 1:
                    ExercicioPrecos(s);
                    break;
                case 2:
                    ExercicioMatriz(s);
                    break;
                case 0:
                    System.out.println("Encerrando o programa...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (Opcao != 0);

        s.close();
    }

    public static void ExercicioPrecos(Scanner s) {
        System.out.print("\nQuantos preços deseja informar? ");
        int n = s.nextInt();

        double[] Precos = new double[n];
        double Soma = 0, Maior = Double.MIN_VALUE, Menor = Double.MAX_VALUE;

        for (int i = 0; i < n; i++) {
            System.out.print("Informe o preço " + (i + 1) + ": ");
            Precos[i] = s.nextDouble();

            Soma += Precos[i];

            if (Precos[i] > Maior) Maior = Precos[i];
            if (Precos[i] < Menor) Menor = Precos[i];
        }

        double Media = Soma / n;

        System.out.println("\n=== RESULTADOS ===");
        System.out.printf("Menor preço: R$ %.2f\n", Menor);
        System.out.printf("Maior preço: R$ %.2f\n", Maior);
        System.out.printf("Média dos preços: R$ %.2f\n", Media);
    }

    public static void ExercicioMatriz(Scanner s) {
        int[][] Alunos = new int[5][2];

        System.out.println("\n=== CADASTRO DE ALUNOS ===");
        for (int i = 0; i < 5; i++) {
            System.out.print("\nInforme o RA do aluno " + (i + 1) + ": ");
            Alunos[i][0] = s.nextInt();

            System.out.print("Informe a quantidade de faltas: ");
            Alunos[i][1] = s.nextInt();

            int RA = Alunos[i][0];
            int Faltas = Alunos[i][1];
            String Status = (Faltas > 20) ? "Reprovado por faltas" : "Aprovado";

            System.out.println("RA: " + RA + " | Faltas: " + Faltas + " | Situação: " + Status);
        }

        System.out.println("\nCadastro concluído!");
    }
}